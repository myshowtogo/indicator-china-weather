<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>CityAddSearchBox</name>
    <message>
        <location filename="../src/cityaddsearchbox.cpp" line="38"/>
        <source>search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CityCollectionWidget</name>
    <message>
        <location filename="../src/citycollectionwidget.cpp" line="61"/>
        <source>Kylin Weather</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LeftUpSearchBox</name>
    <message>
        <location filename="../src/leftupsearchbox.cpp" line="28"/>
        <source>search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.cpp" line="41"/>
        <location filename="../src/mainwindow.cpp" line="301"/>
        <source>Kylin Weather</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="60"/>
        <source>Open Kylin Weather</source>
        <translation type="unfinished"></translation>
    </message>
	<message>
        <location filename="../src/mainwindow.cpp" line="69"/>
        <source>Add City</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="74"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="61"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="104"/>
        <source>Network not connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="251"/>
        <source>Incorrect access address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="253"/>
        <source>Network error code:%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PromptWidget</name>
    <message>
        <location filename="../src/promptwidget.cpp" line="65"/>
        <source>retry</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="71"/>
        <source>KylinWeather</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="75"/>
        <source>show indicator-china-weather test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
